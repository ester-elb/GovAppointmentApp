﻿namespace AppointmentApi.Models
{
    public class Office
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
        public string Address { get; set; }
    }
}
