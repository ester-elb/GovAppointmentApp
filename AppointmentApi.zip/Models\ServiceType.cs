﻿namespace AppointmentApi.Models
{
    public class ServiceType
    {
    }
}
